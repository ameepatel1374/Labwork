
/**
 * This interface represents a set of operations on any newtonian particle.
 */

public interface Particle {
  /**
   * Return the state of this particle as a formatted string.
   *
   * @param time the time
   * @return the state of the particle
   */
  String getStateOfProjectile(float time);
}
