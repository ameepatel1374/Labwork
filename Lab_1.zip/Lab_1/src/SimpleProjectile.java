/**
 * This class implements a Newtonian particle interface.
 */

public class SimpleProjectile implements Particle {

  private float x;
  private float y;
  private float ux;
  private float uy;
  private float g = -9.81f;

  /**
   * Construct a Particle object.
   *
   * @param x  the x position
   * @param y  the y position
   * @param ux the horizontal velocity
   * @param uy the vertical velocity
   */

  public SimpleProjectile(float x, float y, float ux, float uy) {
    this.x = x;
    this.y = y;
    this.ux = ux;
    this.uy = uy;
  }

  /**
   * Return the new horizontal distance.
   *
   * @param x    position of particle
   * @param ux   velocity
   * @param time time used to calculate
   * @return the x_position
   */
  private float computeHorizontalCoordinate(float x, float ux, float time) {
    float newDisplacementX = (float) (ux * time);
    return (x + newDisplacementX);
  }

  /**
   * Return the vertical distance.
   *
   * @param y    current position in y-axis
   * @param uy   vertical velocity
   * @param time time used to calculate
   * @return the yPosition of projectile
   */

  private float computeVerticalCoordinates(float y, float uy, float time) {
    float newDisplacementY = (float) ((uy * time) + ((0.5f) * g * Math.pow(time, 2)));
    return (y + newDisplacementY);
  }

  /**
   * Return the time taken to reach ground.
   *
   * @param uy is vertical velocity
   * @return timeTaken of projectile
   */

  private float timeTakenReachGround(float uy) {
    return Math.abs(2 * (uy) / g);
  }

  /**
   * Return the state of this projectile.
   *
   * @param timeOfParticle the time of the projectile
   * @return String which has the coordinates and time of the projectile
   */
  @Override
  public String getStateOfProjectile(float timeOfParticle) {

    float positionX;
    float positonY;
    float timeToReach;

    if (timeOfParticle <= 0.00) {
      return new String("At time " + String.format("%.2f", timeOfParticle) + ": position is ("
              + String.format("%.2f", x) + "," + String.format("%.2f", y) + ")");
    } else {
      timeToReach = timeTakenReachGround(uy);
      positionX = computeHorizontalCoordinate(x, ux, Math.min(timeToReach, timeOfParticle));
      positonY = computeVerticalCoordinates(y, uy, Math.min(timeToReach, timeOfParticle));

      if (positonY < y) {
        positonY = y;
      }

      return new String("At time " + String.format("%.2f", timeOfParticle) + ": position is ("
              + String.format("%.2f", positionX) + "," + String.format("%.2f", positonY) + ")");
    }
  }
}
