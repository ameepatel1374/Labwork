import org.junit.Test;

import static org.junit.Assert.assertEquals;


/**
 * Test class for the Projectile class.
 */

public class SimpleProjectileTest {

  SimpleProjectile simpleProjectile;

  @Test
  public void timeValueTaken() {
    simpleProjectile = new SimpleProjectile(10, 10, 10, 10);
    assertEquals("At time 0.00: position is (10.00,10.00)", simpleProjectile.getStateOfProjectile((float) 0));
  }

  @Test
  public void calculateValueForProjectile() {
    simpleProjectile = new SimpleProjectile(10, 15, 5, 10);
    assertEquals("At time 4.50: position is (20.19,15.00)", simpleProjectile.getStateOfProjectile((float) 4.5));
  }

  @Test
  public void calculateValueForAnotherProjectile() {
    simpleProjectile = new SimpleProjectile(12, 10, 5, 14);
    assertEquals("At time 2.04: position is (22.19,18.16)", simpleProjectile.getStateOfProjectile((float) 2.0387));
  }


}